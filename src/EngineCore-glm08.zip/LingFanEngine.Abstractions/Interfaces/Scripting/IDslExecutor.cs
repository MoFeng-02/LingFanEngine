using LingFanEngine.Abstractions.Interfaces.Core;

namespace LingFanEngine.Abstractions.Interfaces.Scripting;

/// <summary>
/// DSL 执行器接口
/// <para>纯状态驱动的命令执行器，所有状态保存在状态容器中。</para>
/// <para>外部调用 Step() 推进执行，支持 Say 级回溯。</para>
/// </summary>
public interface IDslExecutor
{
    /// <summary>注册 StoryRegistry（用于自动解析 label 所在文件）</summary>
    void SetStoryRegistry(IStoryRegistry registry);

    /// <summary>加载命令列表和标签索引</summary>
    void LoadCommands(IReadOnlyList<ICommand> commands, IReadOnlyDictionary<string, int>? labels = null);

    /// <summary>从头开始执行</summary>
    void Start();

    /// <summary>从指定 label 开始执行</summary>
    void StartFromLabel(string label);

    /// <summary>单步推进——由 GameLoop 每帧调用</summary>
    bool Step();

    /// <summary>选择菜单选项</summary>
    void SelectMenuOption(int optionIndex);

    /// <summary>提交用户输入</summary>
    void SubmitInput(string value);

    // ========== Say 级回溯 ==========

    /// <summary>是否可以回溯</summary>
    bool CanRollback();

    /// <summary>是否可以前进</summary>
    bool CanRollforward();

    /// <summary>回溯到指定检查点位置</summary>
    bool RollbackTo(int targetPos);

    /// <summary>后退到上一个检查点</summary>
    bool Rollback();

    /// <summary>前进到下一个检查点</summary>
    bool Rollforward();

    /// <summary>清除所有回溯检查点</summary>
    void ClearCheckpoints();
}
